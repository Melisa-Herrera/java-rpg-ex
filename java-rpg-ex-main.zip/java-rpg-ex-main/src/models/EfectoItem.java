package models;

public interface EfectoItem {
  void aplicarEfecto(Jugador jugador, String nombre);
}
