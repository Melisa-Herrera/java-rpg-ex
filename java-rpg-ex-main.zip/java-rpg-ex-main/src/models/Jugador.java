package models;

public class Jugador {
    private boolean bloqueando;

    public Jugador() {
        // Constructor y otros métodos
    }

    public void setBloqueando(boolean bloqueando) {
        this.bloqueando = bloqueando;
    }

    public void recibirDanio(int danio) {
        if (bloqueando) {
            danio *= 0.5;
            bloqueando = false; // Solo bloquea el siguiente ataque
        }
        this.vida -= danio;
        if (this.vida < 0) this.vida = 0;
    }

    public boolean usarPocion() {
        // Lógica para usar una poción y recuperar vida
        return true; // Implementar según la lógica del juego
    }
}
