package actions;

import models.Jugador;
import models.Enemigo;
import managers.GestorCombate;

public class AccionBloqueo implements AccionCombate {
    @Override
    public void ejecutar(Jugador jugador, Enemigo enemigo, GestorCombate gestorCombate) {
        jugador.setBloqueando(true);
        gestorCombate.getInterfaz().mostrarMensaje("Te estás preparando para bloquear el próximo ataque.");
    }
}

