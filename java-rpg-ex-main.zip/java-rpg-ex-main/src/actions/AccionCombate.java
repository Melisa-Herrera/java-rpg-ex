package actions;

import models.Jugador;
import models.Enemigo;
import managers.GestorCombate;

public interface AccionCombate {
    void ejecutar(Jugador jugador, Enemigo enemigo, GestorCombate gestorCombate);
}

