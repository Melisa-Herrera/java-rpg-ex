package actions;

import models.Jugador;
import models.Enemigo;
import managers.GestorCombate;

public class AccionCuracion implements AccionCombate {
    @Override
    public void ejecutar(Jugador jugador, Enemigo enemigo, GestorCombate gestorCombate) {
        if (jugador.usarPocion()) {
            gestorCombate.getInterfaz().mostrarMensaje("Has usado una poción y recuperado vida.");
        } else {
            gestorCombate.getInterfaz().mostrarMensaje("No tienes pociones para usar.");
        }
    }
}
