package actions;

import models.Jugador;
import models.Enemigo;
import managers.GestorCombate;

public class AccionCarga implements AccionCombate {
    @Override
    public void ejecutar(Jugador jugador, Enemigo enemigo, GestorCombate gestorCombate) {
        double nuevoPorcentajeCritico = Math.min(80, gestorCombate.getPorcentajeCritico() + 15);
        gestorCombate.getInterfaz().mostrarMensaje("Cargando... Nuevo porcentaje crítico: " + nuevoPorcentajeCritico + "%");
        gestorCombate.resetearPorcentajeCritico(); // Aumenta el porcentaje crítico
    }
}

