
package managers;

import models.Enemigo;
import models.Jugador;
import ui.Interfaz;
import java.util.Scanner;

public class GestorCombate {
    private Jugador jugador;
    private Interfaz interfaz;
    private double porcentajeCritico;

    public GestorCombate(Jugador jugador, Interfaz interfaz) {
        this.jugador = jugador;
        this.interfaz = interfaz;
        this.porcentajeCritico = 0;
    }

    public double getPorcentajeCritico() {
        return porcentajeCritico;
    }

    public void resetearPorcentajeCritico() {
        this.porcentajeCritico = 0;
    }

    public Interfaz getInterfaz() {
        return interfaz;
    }

    public void pelear(Enemigo enemigo) {
        this.porcentajeCritico = 0; // Reiniciar porcentaje crítico al iniciar un combate
        Scanner scanner = new Scanner(System.in);

        while (jugador.estaVivo() && enemigo.estaVivo()) {
            elegirAccionJugador(enemigo);

            if (enemigo.estaVivo()) {
                interfaz.mostrarMensaje(enemigo.atacar(jugador));
            }

            interfaz.mostrarMensaje("Vida jugador: " + jugador.getVida() + " | Vida enemigo: " + enemigo.getVida());
        }

        if (jugador.estaVivo()) {
            interfaz.mostrarMensaje("Derrotaste a: " + enemigo.getNombre());
        } else {
            interfaz.mostrarMensaje("Moriste, fin del juego.");
        }
    }

    private void elegirAccionJugador(Enemigo enemigo) {
        interfaz.mostrarMensaje("Elige una acción: 1) Atacar 2) Bloquear 3) Cargar 4) Curar");
        Scanner scanner = new Scanner(System.in);
        int opcion = scanner.nextInt();

        AccionCombate accion = null;

        switch (opcion) {
            case 1:
                accion = new AccionAtaque();
                break;
            case 2:
                accion = new AccionBloqueo();
                break;
            case 3:
                accion = new AccionCarga();
                break;
            case 4:
                accion = new AccionCuracion();
                break;
            default:
                interfaz.mostrarMensaje("Opción inválida.");
                return;
        }

        accion.ejecutar(jugador, enemigo, this);
    }
}
